// eSpeak and other code here are under the GNU GPL.
function generateSpeech(text, args) {
  var self = { text: text, args: args, ret: null };
  (function() {

